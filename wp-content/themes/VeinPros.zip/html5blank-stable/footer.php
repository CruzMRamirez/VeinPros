			<!-- footer -->
			<footer class="footer" role="contentinfo">
				<!--Below is where map should be.-->
				<div id="googleMap">

				</div>

				<div class="style-bottom">
				<!--3 divs of info content below-->
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="row">
								<div class="col-sm-6">
									<h3 class="bold-font mbottom">Lorem</h3>
									<ul>
										<li>Lorem Ipsum</li>
										<li>Lorem Ipsum</li>
										<li>Lorem Ipsum</li>
										<li>Lorem Ipsum Dolor</li>
										<li>Lorem</li>
										<li>Lorem</li>
									</ul>
								</div>
								<div class="col-sm-6">
									<h3 class="bold-font mbottom">Lorem Ipsum</h3>
									<ul>
										<li>Lorem Ipsum</li>
										<li>Lorem Ipsum Dolor Sit</li>
										<li>Lorem Ipsum</li>
										<li>Lorem</li>
										<li>Lorem</li>
										<li>Lorem Ipsum Dolor</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-lg-8 col-md-6 center-r-divv">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
					</div>
				<!-- copyright -->
				<div class="text-center">
					<p class="copyright">
						&copy; <?php echo date('Y'); ?> Copyright <?php bloginfo('name'); ?>. <?php _e('Powered by', 'html5blank'); ?>
						<a href="//wordpress.org" title="WordPress">WordPress</a> &amp; <a href="//html5blank.com" title="HTML5 Blank">HTML5 Blank</a>.
					</p>
				</div>
			</div>
				<!-- /copyright -->

			</footer>
			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

		<!-- analytics -->
		<script>
		(function(f,i,r,e,s,h,l){i['GoogleAnalyticsObject']=s;f[s]=f[s]||function(){
		(f[s].q=f[s].q||[]).push(arguments)},f[s].l=1*new Date();h=i.createElement(r),
		l=i.getElementsByTagName(r)[0];h.async=1;h.src=e;l.parentNode.insertBefore(h,l)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
		ga('send', 'pageview');
		</script>

	</body>
</html>
