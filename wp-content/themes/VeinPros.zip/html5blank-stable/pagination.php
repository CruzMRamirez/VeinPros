<!-- pagination -->
<div class="pagination">
	<?php html5wp_pagination(); ?>
</div>
<!-- /pagination -->
